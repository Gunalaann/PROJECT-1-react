import React from 'react';
import './Home.css';
const Home = () => {
  return (
    <div className="welcome-page">
            <h1></h1>
     <div style={{alignItems:'center'}}>
      <img src="https://t3.ftcdn.net/jpg/01/66/84/96/360_F_166849625_tPjczxCHpG1egnai8eUNRg20SSvMjzBT.jpg" ></img>
     </div>
      
    </div>
  );
};

export default Home;